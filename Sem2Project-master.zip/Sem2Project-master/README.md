# Sem2Project
It's the first piece of code i wrote as i began my coding journey
#CHAT-BOT
I built a text based bot using C language 
The bot can read the text sent by a person and give a pre coded response
i added fun little games that could be played with the bot 
